//---------  WEB SERVER ---------//

const http = require('http');
const express = require('express');
const windowmanager = require('windowmanager');

const webPort = 5000;

//Create and start the web server
const app = express();
const server = http.createServer(app);

//Expose the public folder
app.use(express.static('./public'));

//Expose windowmanager scripts on root:+
app.use(express.static(windowmanager.distPath, { index: false }));

//Start the server
server.listen(webPort, () => {
    console.log('Listening on%j\n', server.address());
});

//---------  WEB SOCKETS ---------//

const websocket = require('ws');
const wsServer = new websocket.Server({ server: server });
const api = require('./server/api');

//Set up the websocket listener
wsServer.on('connection', (ws) => {
    console.log('Connection Established:');
    console.log(ws.upgradeReq.headers);
    console.log('\n');

    //Determine the agent type if provided and register the connection
    const qsStart = ws.upgradeReq.url.indexOf('?agent=');
    const agent = qsStart >= 0 ? ws.upgradeReq.url.substr(qsStart + 7) : void 0;
    api.registerConnection(ws, agent);

    //Setup the listeners
    ws.on('message', (raw) => {
        console.log('received: %s\n', raw);
        const message = JSON.parse(raw);
        let args = message.args || [];
        api.broadcastMessage(...args);
    });

    ws.on('close', (status, clientMsg) => {
        api.unregisterConnection(ws);
        console.log(`Client disconnected (${status}) with message: ${clientMsg}\n`);
    });
});
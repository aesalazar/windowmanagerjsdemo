//--------- WINDOW CONTROLS ---------//

var labelHeader = document.getElementById('labelHeader');
var self;

function minimizeWindow() { self.minimize(); }
function maximizeWindow() { self.isMaximized() ? self.restore() : self.maximize(); }
function closeWindow() { self.close(); }

//Get self and set header
windowmanager.onReady(function () {
    self = windowmanager.Window.getCurrent();
    labelHeader.innerText = self.getTitle();
});

//--------- WEBSOCKETS - MESSAGEBUS ---------//

var logOutput = document.getElementById('logOutput');
var textMessage = document.getElementById('textMessage');

function logMessage(msg) {
    logOutput.textContent = msg.text + '\n' + logOutput.textContent;
}

function sendToLocal() {
    var msg = { type: 'local', text: labelHeader.innerText + ': ' + textMessage.value };
    windowmanager.messagebus.send('internal-message', msg);
    logMessage(msg);
}

function sendToServer(agentType) {
    var msg = { type: windowmanager.runtime.name, text: labelHeader.innerText + ': ' + textMessage.value };
    if (agentType) msg.agentType = agentType;
    windowmanager.messagebus.send('external-message', msg);
}

//Setup message listener
windowmanager.onReady(function () {
    windowmanager.messagebus.on('internal-message', logMessage);
});

//---------  WINDOW CREATION ---------//

var windowAppIndex = 0;
var logTextArea = document.getElementById('logTextArea');
var logOutput = document.getElementById('logOutput');

//Create a new window
function createWindow() {
    var config = {
        left: 100, top: 200,
        width: 400, height: 400,
        url: 'child.html',
        title: 'Window' + ++windowAppIndex,
        frame: false
    };

    //Create the window
    var win = new windowmanager.Window(config);
}

function logMessage(msg) {
    logOutput.textContent = msg.text + '\n' + logOutput.textContent;
}

function logText(text) {
    logTextArea.textContent = text + '\n' + logTextArea.textContent;
}

//---------  WEB SOCKETS ---------//

var ws;

//Make the connection to the server
function connect() {
    if (ws != null && ws.readyState === ws.OPEN) return;

    //Create the url for the WebSocket
    var hostname = location.hostname;
    var port = location.port.length > 0 ? ':' + location.port : '';

    //Open the connection to the server and provide the agent type
    var endpoint = 'ws://' + hostname + port + '/?agent=' + windowmanager.runtime.name;
    ws = new WebSocket(endpoint);

    //When connection is opened
    ws.onopen = function (ev) {
        logText('WS connection established: ' + (ws.readyState === ws.OPEN));
    };

    //Listen for responses from the server
    ws.onmessage = function (ev) {
        //Convert external message to internal
        var args = JSON.parse(ev.data).args;
        var newMsg = { type: 'local', text: args[0] + ' ' + args[1] };
        windowmanager.messagebus.send('internal-message', newMsg);
        logMessage(newMsg);
    };
}

function serverMessage(msg) {
    var args = [msg.type, msg.text];
    if (msg.agentType) args.push(msg.agentType);
    ws.send(JSON.stringify({ call: 'broadcastMessage', args: args }));
}

//Setup message listener
windowmanager.onReady(function () {
    windowmanager.messagebus.on('internal-message', logMessage);
    windowmanager.messagebus.on('external-message', serverMessage);
});

//Create initial connection and check for state
connect();
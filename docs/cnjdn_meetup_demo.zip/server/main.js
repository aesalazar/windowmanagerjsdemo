const windowmanager = require('windowmanager');
windowmanager.start();